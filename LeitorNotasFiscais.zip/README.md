# Leitor de Notas Fiscais

Aplicativo Android básico para registrar:
- Data
- Hora
- Nome do entregador

Próxima etapa: integrar a câmera e OCR para preencher esses campos automaticamente a partir da foto da nota fiscal.
