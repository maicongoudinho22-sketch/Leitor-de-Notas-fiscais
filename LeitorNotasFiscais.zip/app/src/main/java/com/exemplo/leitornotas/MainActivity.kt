package com.exemplo.leitornotas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Registro(val data: String, val hora: String, val entregador: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LeitorNotasApp() }
    }
}

@Composable
fun LeitorNotasApp() {
    var data by remember { mutableStateOf("") }
    var hora by remember { mutableStateOf("") }
    var entregador by remember { mutableStateOf("") }
    val registros = remember { mutableStateListOf<Registro>() }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Leitor de Notas Fiscais") }) }
        ) { padding ->
            Column(
                Modifier.padding(padding).padding(16.dp).fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Dados da nota", style = MaterialTheme.typography.titleLarge)

                OutlinedTextField(data, { data = it }, label = { Text("Data") },
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(hora, { hora = it }, label = { Text("Hora") },
                    modifier = Modifier.fillMaxWidth())
                OutlinedTextField(entregador, { entregador = it }, label = { Text("Nome do entregador") },
                    modifier = Modifier.fillMaxWidth())

                Button(
                    onClick = {
                        if (data.isNotBlank() || hora.isNotBlank() || entregador.isNotBlank()) {
                            registros.add(Registro(data, hora, entregador))
                            data = ""; hora = ""; entregador = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Salvar registro") }

                Text("Registros", style = MaterialTheme.typography.titleLarge)

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(registros) { r ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text("Data: ${r.data}")
                                Text("Hora: ${r.hora}")
                                Text("Entregador: ${r.entregador}")
                            }
                        }
                    }
                }
            }
        }
    }
}
